package com.utils;

public class WrapperError implements Wrapper {
	MetaData metaData;
	Error error;
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	public Error getError() {
		return error;
	}
	public void setError(Error error) {
		this.error = error;
	}
	public void setData(Object data) {
		
	}
}
