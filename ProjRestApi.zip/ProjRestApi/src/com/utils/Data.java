package com.utils;

import java.util.ArrayList;
import java.util.List;

public class Data {
	List<Object> data = new ArrayList<Object>();
	
	public List<Object> getData() {
		return data;
	}
	
	public void setData(Object data) {
		this.data.add(data);
	}
}
