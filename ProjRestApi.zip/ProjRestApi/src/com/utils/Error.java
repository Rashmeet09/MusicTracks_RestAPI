package com.utils;

public enum Error {
	NOTFOUND(404),
	INVALIDDATA(500),
	NOTLOGGEDIN(410),
	UNDEFINED(900);
		private int code;
		private Error(int code) {
			this.code = code;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}	
}
