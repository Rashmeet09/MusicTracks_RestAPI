package com.spring;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Track {
		int id;
		String title;
		String artist;
		String album;
		String genre;
		
		@JsonCreator
		 public Track(@JsonProperty("id") int id, @JsonProperty("title") String title,
		   @JsonProperty("artist") String artist, @JsonProperty("album") String album, 
		   @JsonProperty("genre") String genre) {
			  this.id = id;
			  this.title = title;
			  this.artist = artist;
			  this.album = album;
			  this.genre = genre;
		 }
		
		public Track() {			
		}
		
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getArtist() {
			return artist;
		}
		public void setArtist(String artist) {
			this.artist = artist;
		}
		public String getAlbum() {
			return album;
		}
		public void setAlbum(String album) {
			this.album = album;
		}
		public String getGenre() {
			return genre;
		}
		public void setGenre(String genre) {
			this.genre = genre;
		}

		@Override
		 public String toString() {
		  StringBuilder str = new StringBuilder();
		  str.append("Track Id:- " + getId());
		  str.append("Title:- " + getTitle());
		  str.append("Artist:- " + getArtist());
		  str.append("Album:- " + getAlbum());
		  str.append("Genre:- " + getGenre());
		  return str.toString();
	   }
}
