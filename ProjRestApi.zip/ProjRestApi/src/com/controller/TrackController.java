package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Track;
import com.utils.Wrapper;
import com.utils.Error;
import com.utils.Data;
import com.utils.MetaData;
import com.utils.WrapperError;
import com.utils.WrapperImpl;
import com.service.*;

@RestController
public class TrackController {
	
	@Autowired
	private TrackService ts;
	
	/*display all tracks*/
	@RequestMapping(value = "/tracks", method = RequestMethod.GET, produces = "application/json")  
	 public ResponseEntity<Wrapper> tracks() {	
		  HttpHeaders headers = new HttpHeaders();
		  List<Track> Tracks = ts.getTracks();
		  if (Tracks == null) {
			  return new ResponseEntity<Wrapper>(fetchFailed("No tracks Found",Error.NOTFOUND),HttpStatus.NOT_FOUND);
		  }
		  headers.add("Number Of Records Found", String.valueOf(Tracks.size()));
		  return new ResponseEntity<Wrapper>(found("Tracks Found:"+Tracks.size(),Tracks), headers, HttpStatus.OK);
	 }
	
	/*display track from id*/
	 @RequestMapping(value = "/tracks/{id}", method = RequestMethod.GET)            
	 public ResponseEntity<Wrapper> getTrack(@PathVariable("id") int TrackId) {
		 HttpHeaders headers = new HttpHeaders();
		  Track Track = ts.getTrack(TrackId);
		  if (Track == null) {
			  return new ResponseEntity<Wrapper>(fetchFailed("No tracks Found",Error.NOTFOUND),HttpStatus.NOT_FOUND);
		  }
		  return new ResponseEntity<Wrapper>(found("Tracks Found:"+1,Track), headers, HttpStatus.OK);
	 }

	 /*delete track from id*/
	 @RequestMapping(value = "/tracks/deletes/{id}", method = RequestMethod.DELETE) 
	 public ResponseEntity<Wrapper> deleteTrack(@PathVariable("id") int TrackId) {
		  HttpHeaders headers = new HttpHeaders();
		  Track Track = ts.getTrack(TrackId);
		  if (Track == null) {   
			  return new ResponseEntity<Wrapper>(fetchFailed("No tracks Found",Error.NOTFOUND),HttpStatus.NOT_FOUND);
		  }
		  ts.deleteTrack(TrackId);
		  headers.add("Track Deleted - ", String.valueOf(TrackId));
		  return new ResponseEntity<Wrapper>(found("Tracks Found:"+1,Track), headers, HttpStatus.OK);
	 }

	 @RequestMapping(value = "/tracks", method = RequestMethod.POST,produces = "application/json")
	 public ResponseEntity<Wrapper> createTrack(@RequestBody Track Track) {   /*insert track*/
		  HttpHeaders headers = new HttpHeaders();
		  if (Track == null) {
			  return new ResponseEntity<Wrapper>(fetchFailed("No tracks Found",Error.NOTFOUND),HttpStatus.NOT_FOUND);
		  }
		  ts.createTrack(Track);
		  headers.add("Track Created  - ", String.valueOf(Track.getId()));
		  return new ResponseEntity<Wrapper>(found("Tracks Found:"+1,Track), headers, HttpStatus.OK);
	 }

	 /*update track*/
	 @RequestMapping(value = "/tracks/{id}", method = RequestMethod.PUT) 
	 public ResponseEntity<Wrapper> updateTrack(@PathVariable("id") int TrackId, @RequestBody Track Track) {
		  HttpHeaders headers = new HttpHeaders();
		  Track isExist = ts.getTrack(TrackId);
		  if (isExist == null) {   
			  return new ResponseEntity<Wrapper>(fetchFailed("No tracks Found",Error.NOTFOUND),HttpStatus.NOT_FOUND);
		  } 
		  else if (Track == null) {
			  return new ResponseEntity<Wrapper>(HttpStatus.BAD_REQUEST);
		  }
		  ts.updateTrack(Track);
		  headers.add("Track Updated  - ", String.valueOf(TrackId));
		  return new ResponseEntity<Wrapper>(found("Tracks Found:"+1,Track), headers, HttpStatus.OK);
	 }
	 
	 private Wrapper fetchFailed(String msg, Error error){
			Wrapper result = new WrapperError();
			MetaData meta = new MetaData();
			meta.setMessage(msg);
			meta.setStatus(false);
			result.setMetaData(meta);
			result.setError(error);
			return result;
	}
	 
	private Wrapper found(String msg,Object object){
			Wrapper result = new WrapperImpl();
			MetaData meta = new MetaData();
			meta.setMessage(msg);
			meta.setStatus(true);
			result.setMetaData(meta);
			Data data = new Data();
			data.setData(object);
			result.setData(object);
			return result;
		}
}
