package com.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.Track;
import com.dao.*;

@Service("TrackService")
public class TrackService {
	 @Autowired
	 private TrackDao TrackDao;

	 public List<Track> getTracks() {
		  List<Track> Tracks = TrackDao.getTracks();
		  return Tracks;
	 }
	 
	 public int createTrack(Track Track) {
		  return TrackDao.createTrack(Track);
	 }

	 public Track getTrack(int TrackId) {
		  Track Track = TrackDao.getTrack(TrackId);
		  return Track;
	 }

	 public int deleteTrack(int TrackId) {
		 return TrackDao.deleteTrack(TrackId);
	 }

	 public int updateTrack(Track Track) {
		 return TrackDao.updateTrack(Track);
	 } 
}
