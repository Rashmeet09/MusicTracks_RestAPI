package com.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.spring.Track;
@Repository("TrackDao")
public class TrackDao {

	 private JdbcTemplate jdbcTemplate;

	 @Autowired
	 public void setDataSource(DataSource dataSource) {
	  this.jdbcTemplate = new JdbcTemplate(dataSource);
	 }

	 public List<Track> getTracks() {
		  List<Track> Tracks = null ;	  
		  try {
			  Tracks = jdbcTemplate.query("SELECT * FROM trackinfo order by id",new BeanPropertyRowMapper<Track>(Track.class));   
		  } 
		  catch (DataAccessException e) {
			  e.printStackTrace();
		  }
		  return Tracks;
	 }

	 public Track getTrack(int TrackId) {
		  Track Track = null;
		  try {
			  Track = jdbcTemplate.queryForObject("SELECT * FROM trackinfo WHERE id = ?",
		      new Object[] { TrackId }, new BeanPropertyRowMapper<Track>(Track.class));
		  } 
		  catch (DataAccessException e) {
			  e.printStackTrace();
		  }
		  return Track;
	 }

	 public int deleteTrack(int TrackId) {
		  int count = jdbcTemplate.update("DELETE from trackinfo WHERE id = ?", new Object[] { TrackId });
		  return count;
	 }

	 public int updateTrack(Track Track) {
		  int count = jdbcTemplate.update(
		    "UPDATE trackinfo set title = ? , artist = ? , album = ? , genre = ? where id = ?", new Object[] {
		      Track.getTitle(), Track.getArtist(), Track.getAlbum(), Track.getGenre(), Track.getId() });
		  return count;
	 }

	 public int createTrack(Track Track) {
		 int count = jdbcTemplate.update(
	    "INSERT INTO trackinfo(id, title, artist, album, genre) VALUES(?,?,?,?,?)", new Object[] {
	      Track.getId(), Track.getTitle(), Track.getArtist(), Track.getAlbum(), Track.getGenre() });
		 return count;
	 }

}
